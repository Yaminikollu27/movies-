module.exports = {
	'APIKey': 'd49014bc'
};